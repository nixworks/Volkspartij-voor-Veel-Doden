from setuptools import setup, find_packages

setup(name='satoshidicetools',
      version='0.1',
      description='Satoshidice tools',
      author='tranq',
      author_email='edoomik@gmail.com',
      url='',
      packages = find_packages()
     )
